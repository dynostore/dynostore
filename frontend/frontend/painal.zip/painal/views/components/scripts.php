<!-- Main scripts -->
<script src="<?php echo PROJECT_HOME;?>/vendors/bundle.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.4/raphael-min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/justgage/1.2.9/justgage.min.js"></script>

<!-- Apex chart -->
<script src="https://apexcharts.com/samples/assets/irregular-data-series.js"></script>
<script src="<?php echo PROJECT_HOME;?>/vendors/charts/apex/apexcharts.min.js"></script>

<!-- Dashboard scripts -->
<script src="<?php echo PROJECT_HOME;?>/assets/js/examples/pages/file-dashboard.js"></script>

<!-- App scripts -->
<script src="<?php echo PROJECT_HOME;?>/assets/js/app.min.js"></script>